struct Inca: Hashable {
    let nombre: String
    let reinado: String
    let duracion: Int
}

let incas: Set<Inca> = [
    Inca(nombre: "Manco Capac",             reinado: "1150-1178", duracion: 28),
    Inca(nombre: "Sinchi Roca",             reinado: "1178-1197", duracion: 19),
    Inca(nombre: "Lloque Yupanqui",         reinado: "1197-1246", duracion: 49),
    Inca(nombre: "Mayta Capac",             reinado: "1246-1276", duracion: 30),
    Inca(nombre: "Capac Yupanqui",          reinado: "1276-1321", duracion: 45),
    Inca(nombre: "Inca Roca",               reinado: "1321-1348", duracion: 21),
    Inca(nombre: "Yahuar Huacac",           reinado: "1348-1370", duracion: 22),
    Inca(nombre: "Huiracocha",              reinado: "1370-1420", duracion: 50),
    Inca(nombre: "Pachacutec Inca Yupanqui", reinado: "1420-1477", duracion: 57),
    Inca(nombre: "Amaru Inca Yupanqui",     reinado: "1478",      duracion: 1),
    Inca(nombre: "Tupac Inca Yupanqui",     reinado: "1478-1488", duracion: 10),
    Inca(nombre: "Huayna Capac",            reinado: "1488-1525", duracion: 37),
    Inca(nombre: "Huascar",                 reinado: "1525-1532", duracion: 7),
    Inca(nombre: "Atahualpa",               reinado: "1525-1533", duracion: 8)
]

let buscar = "Atahualpa"
let encontrado = incas.contains { $0.nombre == buscar }
print("\(buscar) registrado: \(encontrado)")

let nombres: Set<String> = Set(incas.map { $0.nombre })
print("Nombres sin duplicados: \(nombres)")

let yupanquis = incas.filter { $0.nombre.uppercased().contains("YUPANQUI") }
print("Incas con Yupanqui:")
yupanquis.forEach { print("  \($0.nombre) — \($0.reinado)") }

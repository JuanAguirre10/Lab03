let frase1 = "Welcome to Tecsup today is a beautiful day"
let frase2 = "In Tecsup we are learning swift"

let conectores: Set<String> = ["to", "is", "in", "are", "a"]

let traducciones: [String: String] = [
    "welcome": "bienvenido",
    "today": "hoy",
    "beautiful": "hermoso",
    "day": "día",
    "we": "nosotros",
    "learning": "aprendiendo",
]

func procesarFrase(_ frase: String) -> String {
    let palabras = frase.split(separator: " ")
    var resultado = ""
    
    for palabraSeparada in palabras {
        let palabra = String(palabraSeparada)
        
        if !conectores.contains(palabra) {
            let traduccion = traducciones[palabra] ?? palabra
            
            if resultado.isEmpty {
                resultado = traduccion
            } else {
                resultado += " " + traduccion
            }
        }
    }
    
    return resultado
}

let resultado1 = procesarFrase(frase1)
let resultado2 = procesarFrase(frase2)

print(resultado1)
print(resultado2)

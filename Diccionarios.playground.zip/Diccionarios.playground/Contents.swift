import Cocoa

var greeting = "Hello, playground"
import Foundation
let metroLima: [String: [String]] = [
    "Línea 1": [
        "Villa El Salvador", "Parque Industrial", "Pumacahua",
        "Villa María", "María Auxiliadora", "San Juan",
        "Atocongo", "Jorge Chávez", "Ayacucho", "Cabitos",
        "Angamos", "San Borja Sur", "La Cultura", "Arriola",
        "Gamarra", "Miguel Grau", "El Ángel",
        "Presbítero Maestro", "Caja de Agua", "Pirámide del Sol",
        "Los Jardines", "Los Postes", "San Carlos",
        "San Martín", "Bayóvar", "El Bosque"
    ],
    "Línea 2": [
        "Ate", "Santa Anita", "Mercado Santa Anita",
        "San Juan de Dios", "Evitamiento", "Nicolás Ayllón",
        "28 de Julio", "Estadio Nacional", "Central",
        "Plaza Bolognesi", "Arica", "Venezuela",
        "Germán Amézaga", "Óscar R. Benavides",
        "Guardia Chalaca", "Puerto del Callao",
        "Los Incas", "La Perla", "Bellavista",
        "Carmen de la Legua", "Faucett", "Aeropuerto",
        "Colonial", "Breña", "San Luis",
        "El Agustino", "La Victoria"
    ],
    "Línea 3": [
        "Comas Norte", "Comas Centro", "El Retablo",
        "Independencia", "Universitaria", "Los Olivos",
        "Naranjal", "Izaguirre", "Túpac Amaru",
        "Tacna", "Colmena", "San Martín de Porres",
        "Quilca", "Arequipa", "Lince",
        "Javier Prado", "San Isidro Norte", "San Isidro Sur",
        "Miraflores", "Ricardo Palma", "Surco",
        "Angamos Sur", "Primavera", "Tomás Marsano",
        "Higuereta", "Benavides", "Matellini",
        "San Juan de Miraflores"
    ],
    "Línea 4": [
        "Gambetta", "Los Ferroles", "Boterín",
        "Faucett Aeropuerto", "Tomás Valle", "Universitaria Norte",
        "Javier Prado Oeste", "Javier Prado Este",
        "La Molina", "Huachipa", "Santa Anita Este"
    ],
    "Línea 4 Ramal": [
        "Faucett", "Aeropuerto Jorge Chávez",
        "Boterín", "Gambetta"
    ]
]
print("ESTACIONES POR LÍNEA")
print("---------------------")
func mostrarEstacionesDe(linea: String) {
    if let estaciones = metroLima[linea] {
        print("\n Estaciones de \(linea) (\(estaciones.count) estaciones):")
        for (index, estacion) in estaciones.enumerated() {
            print("   \(index + 1). \(estacion)")
        }
    } else {
        print("  La línea '\(linea)' no existe en la red.")
    }
}
mostrarEstacionesDe(linea: "Línea 1")
mostrarEstacionesDe(linea: "Línea 3")
print(" ¿A QUÉ LÍNEA(S) PERTENECE UNA ESTACIÓN?")
print("-------------------------")
func lineasDeEstacion(_ estacion: String) {
    var lineasEncontradas: [String] = []
    for (linea, estaciones) in metroLima {
        if estaciones.contains(estacion) {
            lineasEncontradas.append(linea)
        }
    }
    if lineasEncontradas.isEmpty {
        print("\n'\(estacion)' no fue encontrada en ninguna línea.")
    } else {
        print("\n La estación '\(estacion)' pertenece a:")
        for linea in lineasEncontradas.sorted() {
            print("    \(linea)")
        }
        if lineasEncontradas.count > 1 {
            print("   Es una estación de TRANSFERENCIA")
        }
    }
}
lineasDeEstacion("28 de Julio")
lineasDeEstacion("Faucett")
lineasDeEstacion("Bayóvar")
lineasDeEstacion("Miraflores Centro")
print("  ¿UNA ESTACIÓN PERTENECE A UNA LÍNEA ESPECÍFICA?")
print ("----------------------")
func perteneceEstacion(_ estacion: String, aLinea linea: String) {
    guard let estaciones = metroLima[linea] else {
        print("\n La línea '\(linea)' no existe.")
        return
    }
    if estaciones.contains(estacion) {
        print("\n '\(estacion)' SÍ pertenece a \(linea).")
    } else {
        print("\n '\(estacion)' NO pertenece a \(linea).")
    }
}
perteneceEstacion("Gamarra",           aLinea: "Línea 1")
perteneceEstacion("Gamarra",           aLinea: "Línea 2")
perteneceEstacion("Miraflores",        aLinea: "Línea 3")
perteneceEstacion("Aeropuerto",        aLinea: "Línea 4 Ramal")
perteneceEstacion("Villa El Salvador", aLinea: "Línea 2")
print("  CANTIDAD DE ESTACIONES POR LÍNEA")
print("------------------------------")
func cantidadEstaciones(de linea: String) {
    if let estaciones = metroLima[linea] {
        print("    \(linea): \(estaciones.count) estaciones")
    } else {
        print("  La línea '\(linea)' no existe.")
    }
}
print("\n Resumen de la Red Metro Lima 2040:")
for linea in metroLima.keys.sorted() {
    cantidadEstaciones(de: linea)
}
let totalEstaciones = metroLima.values.reduce(0) { $0 + $1.count }
print("\n Total de estaciones en la red: \(totalEstaciones)")
print(" RESUMEN RED METRO DE LIMA 2040")
print("   • Total de líneas  : \(metroLima.count)")
print("   • Total estaciones : \(totalEstaciones)")
if let lineaMasLarga = metroLima.max(by: { $0.value.count < $1.value.count }) {
    print("   • Línea más larga  : \(lineaMasLarga.key) con \(lineaMasLarga.value.count) estaciones")
}
    

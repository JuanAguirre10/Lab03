let paises: [String] = [
    "Argentina", "Bolivia", "Brasil", "Chile",
    "Colombia", "Ecuador", "Mexico", "Peru",
    "Paraguay", "Uruguay", "Venezuela"
]

var gdp2025: [Double] = [
    683.371, 57.086, 2256.910, 347.174,
    438.121, 130.529, 1862.740, 318.480,
    47.398, 84.986, 82.767
]

print("GDP Bolivia 2025: \(gdp2025[1]) B")

gdp2025[7] = 326.608
print("GDP Peru actualizado: \(gdp2025[7]) B")

gdp2025[7] = 318.480
print("GDP Peru restaurado: \(gdp2025[7]) B")

let suma = gdp2025.reduce(0, +)
let promedio = suma / Double(gdp2025.count)
print("Promedio GDP: \(promedio) B")

let promedioReduce = gdp2025.reduce(0.0) { $0 + $1 } / Double(gdp2025.count)
print("Promedio con reduce: \(promedioReduce) B")

let maxGDP = gdp2025.max()!
let idxMax = gdp2025.firstIndex(of: maxGDP)!
print("GDP mas alto: \(paises[idxMax]) con \(maxGDP) B")

let filtrados = paises.enumerated().filter { gdp2025[$0.offset] > 300 }
print("Paises con GDP mayor a 300 B:")
filtrados.forEach { print("  \($0.element)") }

let ranking = zip(paises, gdp2025).sorted { $0.1 > $1.1 }
print("Paises ordenados por GDP:")
ranking.enumerated().forEach { i, par in
    print("  \(i + 1). \(par.0): \(par.1) B")
}
